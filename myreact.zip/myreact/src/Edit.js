// import axios from "axios";
// import React, {useState,useEffect} from "react";

// function Edit() {
//     useEffect(()=>{
//         axios.get('http://localhost:3000/dashboard')
//         .then( => {

//         })
//     },[])
//     return(
//         <div className="container" mt-5>
//             <table className="table">
//                 <tbody>
                    
//                 </tbody>
//             </table>
//         </div>
//     )
// }

import React from 'react'

const Edit = () => {
  return (
    <div>
      <h1>edit page
      </h1>
    </div>
  )
}

export default Edit
