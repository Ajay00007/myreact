import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import './App.css';
import EmployeeList from './components/employee-list/EmployeeList';
import LoginPage from './components/LoginPage/LoginPage';

function App() {
  return (
    <Router>
    <Routes>
    <Route exact path="/" element={<LoginPage />} />
    <Route exact path="/dashboard" element={<EmployeeList />} />

    </Routes>
  </Router>
  );
}

export default App;
