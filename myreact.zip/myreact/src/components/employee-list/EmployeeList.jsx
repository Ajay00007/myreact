import React from 'react';
 import './EmployeeList.css';

class EmployeeList extends React.Component {
  constructor() {
    super();
    this.state = {
      users: null,
    };
  }

  componentDidMount() {
    fetch('https://api.randomuser.me/?nat=US&results=20').then((response) => {
      response.json().then((result) => {
        // console.warn(result.data);
        this.setState({ users:result.results });
      });
    });
  }
  render() {
    return (
      <div>

<table>
  <tr>
    <th>No.</th>
    <th>ID</th>
    <th>NAME</th>
    <th>SEX</th>
    <th>DOB</th>
    {/* <th>SALARY</th>
    <th>DEPARTMENT</th> */}
  </tr>
  
  {this.state.users
          ? this.state.users.map((item, i) => (
            <>
              <tr>
                <td>  {i+1} {' '}</td>
                <td>  {item.id.name} {' '}</td>
                <td>  {item.name.first} {item.name.last}{' '}</td>
                <td>  {item.gender} {' '}</td>
                <td>  {item.dob.date} {' '}</td>
                {/* <td>  <button>Edit</button></td> */}
                <td>  <button>Delete</button></td>
                <a class="btn btn-primary" href="#" role="button">Add</a>
                

                <a class="btn btn-primary" href="#" role="button">Edit</a>
                {/* <a class="btn btn-primary" href="#" role="button">Delete</a> */}


                </tr>
            </>
           
            ))
          : null}


</table>

        
      </div>
    );
  }
}

export default EmployeeList;
